//Primitive Datatypes
var x = 5;
var y = 5;
console.log("==>3", x==y);
console.log("==>4", x===y);

//Reference Datatypes
var xObj = {
    name: "Suresh"
};

/*var yObj = {
    name: "Suresh"
}; */
var yObj = xObj;
console.log("==>14", xObj==yObj);
console.log("==>15", xObj===yObj);