/*console.log("Hello World");
var a = 10;
var b = 20;
console.log(a+b); */
alert("Warning!");