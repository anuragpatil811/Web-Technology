// 1. primitive
/*
var firstName = "suresh";
console.log("==>4", firstName);
var firstNameTwo = firstName; 
firstName = "SURESH";
console.log("==>9", firstName, firstNameTwo); 
*/

//2. Reference
var personObj = {
    firstName: "Anurag",
    lastName: "Stark",
    books: ["Book 1", "Book 2", "Book 3"]
}
var newPersonObj = {     //It will be stored on different memory location
     firstName: "Anurag",
    lastName: "Stark",
    books: ["Book 1", "Book 2", "Book 3"]
}
/*console.log("==>14"  ,personObj);
//personObj.firstName="Tony";
var personTwoObj = personObj;
personObj.firstName="Tony";
console.log("==>17"  ,personObj);
console.log("==>18", personTwoObj); //personObj and personTwoObj are pointing to the same object in memory.
*/

//var newFirstname = personObj.firstName;
//newFirstname = "Tome";
//console.log("==>24", personObj, newFirstname);  //String is a primitive Datatype
var newBooksArray = personObj.books;   
newBooksArray[0] = "AI Fundamentals";  //Array is a reference datatype
console.log("==>24", personObj, newBooksArray);
