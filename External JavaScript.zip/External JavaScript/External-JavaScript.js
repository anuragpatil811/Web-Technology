//console.log("Connected the JavaScript file to the HTML file");
var el = document.getElementById("header");
console.log(el);
function displayName()
{
    var name = "Anurag";
    console.log(name);
}
displayName();